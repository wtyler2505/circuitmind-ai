| From | Pin | To | Pin | Wire |
|---|---|---|---|---|
| `arduino-uno` | `5V` | `hc-sr04` | `VCC` | `red` |
| `arduino-uno` | `GND` | `hc-sr04` | `GND` | `black` |
| `arduino-uno` | `D9` | `hc-sr04` | `TRIG` | `green` |
| `arduino-uno` | `D10` | `hc-sr04` | `ECHO` | `yellow` |
