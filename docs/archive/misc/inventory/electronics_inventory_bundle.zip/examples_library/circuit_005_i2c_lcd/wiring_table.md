| From | Pin | To | Pin | Wire |
|---|---|---|---|---|
| `arduino-uno` | `5V` | `lcd1602-i2c` | `VCC` | `red` |
| `arduino-uno` | `GND` | `lcd1602-i2c` | `GND` | `black` |
| `arduino-uno` | `A4` | `lcd1602-i2c` | `SDA` | `blue` |
| `arduino-uno` | `A5` | `lcd1602-i2c` | `SCL` | `yellow` |
