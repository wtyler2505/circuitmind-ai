| From | Pin | To | Pin | Wire |
|---|---|---|---|---|
| `arduino-uno` | `3.3V` | `mpu6050` | `VCC` | `orange` |
| `arduino-uno` | `GND` | `mpu6050` | `GND` | `black` |
| `arduino-uno` | `A4` | `mpu6050` | `SDA` | `blue` |
| `arduino-uno` | `A5` | `mpu6050` | `SCL` | `yellow` |
