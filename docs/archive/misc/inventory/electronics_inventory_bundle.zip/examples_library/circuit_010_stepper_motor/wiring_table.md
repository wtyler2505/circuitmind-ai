| From | Pin | To | Pin | Wire |
|---|---|---|---|---|
| `power-supply-5v` | `+` | `uln2003` | `VCC` | `red` |
| `power-supply-5v` | `-` | `uln2003` | `GND` | `black` |
| `arduino-uno` | `GND` | `uln2003` | `GND` | `black` |
| `arduino-uno` | `D8` | `uln2003` | `IN1` | `yellow` |
| `arduino-uno` | `D9` | `uln2003` | `IN2` | `orange` |
| `arduino-uno` | `D10` | `uln2003` | `IN3` | `green` |
| `arduino-uno` | `D11` | `uln2003` | `IN4` | `blue` |
| `uln2003` | `MOTOR` | `28byj48` | `connector` | `ribbon` |
