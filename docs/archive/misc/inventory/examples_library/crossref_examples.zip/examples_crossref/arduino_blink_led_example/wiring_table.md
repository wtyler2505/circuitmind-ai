| Component | Pin | Arduino Uno Connection | Notes |
|---|---|---|---|
| LED | Anode | Digital pin 8 via 220 Ω resistor | Positive leg of the LED |
| LED | Cathode | GND | Negative leg of the LED |
| 220 Ω resistor | lead 1 | LED Anode | Limits current through the LED |
| 220 Ω resistor | lead 2 | Digital pin 8 | Connects resistor to the microcontroller pin |