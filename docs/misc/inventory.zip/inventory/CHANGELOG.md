# Changelog

## 2025-12-31
- Generated `inventory.production.json` from Tier 5 JSON (superset).
- Reconciled `inventory_metadata.last_updated` to match Tier 5 MD headers (2025-12-31).
- Exported wiring ruleset (Tier 4/5) into `wiring_ruleset/`.
- Exported complete circuits into `examples_library/` with sketches and wiring tables.
