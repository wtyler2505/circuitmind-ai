| From | Pin | To | Pin | Wire |
|---|---|---|---|---|
| `arduino-uno` | `D13` | `resistor-220ohm` | `1` | `yellow` |
| `resistor-220ohm` | `2` | `led-red` | `anode` | `yellow` |
| `led-red` | `cathode` | `arduino-uno` | `GND` | `black` |
