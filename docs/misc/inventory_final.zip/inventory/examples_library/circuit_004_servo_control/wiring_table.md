| From | Pin | To | Pin | Wire |
|---|---|---|---|---|
| `arduino-uno` | `5V` | `sg90` | `VCC-red` | `red` |
| `arduino-uno` | `GND` | `sg90` | `GND-brown` | `black` |
| `arduino-uno` | `D9` | `sg90` | `SIGNAL-orange` | `orange` |
