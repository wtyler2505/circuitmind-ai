| From (component/pin) | To (component/pin) | Wire Color |
|---|---|---|
| Arduino Uno R3 — 5 V | Relay Module — VCC | red |
| Arduino Uno R3 — GND | Relay Module — GND | black |
| Arduino Uno R3 — D7 | Relay Module — IN | yellow |
